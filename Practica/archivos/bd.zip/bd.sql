DROP DATABASE IF EXISTS practica;
CREATE DATABASE practica;
USE practica;

---TABLAS

CREATE TABLE usuario(
    id INT AUTO_INCREMENT,
    nombre VARCHAR(25),
    rut VARCHAR(25),
    edad TINYINT(2),
    cargo VARCHAR(25),
    email VARCHAR(25),

    PRIMARY KEY(id),
    UNIQUE(rut)
);

CREATE TABLE ups(
    id INT AUTO_INCREMENT,
    marca VARCHAR(25),
    n_de_serie VARCHAR(25),
    modelo VARCHAR(25),

    PRIMARY KEY(id)
);

CREATE TABLE telefono(
    id INT AUTO_INCREMENT,
    marca VARCHAR(25),
    n_serie VARCHAR(25),
    modelo VARCHAR(25),
    tipo_tecno VARCHAR(25),

    PRIMARY KEY(id)
);

CREATE TABLE modelo(
    id INT AUTO_INCREMENT,
    nombre VARCHAR(25),

    PRIMARY KEY(id)
);

CREATE TABLE marca(
    id INT AUTO_INCREMENT,
    nombre VARCHAR(25),
    modelo_id_fk INT,

    PRIMARY KEY(id),
    FOREIGN KEY(modelo_id_fk) REFERENCES modelo(id)
);

CREATE TABLE equipo(
    id INT AUTO_INCREMENT,
    tipo_pc VARCHAR(25),
    centro_de_costo VARCHAR(25),
    n_serie VARCHAR(25),
    licencia VARCHAR(25),
    estado VARCHAR(25),
    responsable VARCHAR(25),
    fecha_de_ingreso DATE,
    marca_id_fk INT,

    PRIMARY KEY(id),
    FOREIGN KEY(marca_id_fk) REFERENCES marca(id)
);

CREATE TABLE boxx(
    id INT AUTO_INCREMENT,
    numero INT(20),
    nombre VARCHAR(25),
    telefono_id_fk INT,
    equipo_id_fk INT,
    ups_id_fk INT,

    PRIMARY KEY(id),
    FOREIGN KEY(telefono_id_fk) REFERENCES telefono(id),
    FOREIGN KEY(equipo_id_fk) REFERENCES equipo(id),
    FOREIGN KEY(ups_id_fk) REFERENCES ups(id)
);

CREATE TABLE sector(
    id INT AUTO_INCREMENT,
    boxx_id_fk INT,

    PRIMARY KEY(id),
    FOREIGN KEY(boxx_id_fk) REFERENCES boxx(id)
);

CREATE TABLE box_sector(
    id INT AUTO_INCREMENT,
    boxx_id_fk INT,
    sector_id_fk INT,

    PRIMARY KEY(id),
    FOREIGN KEY(boxx_id_fk) REFERENCES boxx(id),
    FOREIGN KEY(sector_id_fk) REFERENCES sector(id)
);